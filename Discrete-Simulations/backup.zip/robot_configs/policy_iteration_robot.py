import random
import numpy as np

max_iter = 100
discount = 0.5

def robot_epoch(robot):
    # Initialisation
    grid = robot.grid

    rewards = {}
    for i in range(0, grid.n_cols):
        for j in range(0, grid.n_rows):
            rewards[(i,j)] = grid.cells[i, j].copy()

    #print(f'rewards: {rewards}')

    print(f'\t\t 0 \t\t 1 \t\t 2 \t\t 3 \t\t 4 \t\t 5 \t\t 6')
    for i in range(7):
        if i in [0, 6]:
            print(f'{i} | wall \t wall \t wall \t wall \t wall \t wall \t wall \t')
        else:
            print(
                f'{i} | wall \t {rewards[(1, i)]} \t {rewards[(2, i)]} \t {rewards[(3, i)]} \t {rewards[(4, i)]} \t {rewards[(5, i)]} \t wall \t')

    values = rewards.copy()

    actions = {}
    for i in range(0, grid.n_cols):
        for j in range(0, grid.n_rows):
            possible_actions = get_possible_actions(grid, (i, j))
            # Ensure only keys get added when there are actions
            if len(possible_actions) != 0:
                actions[(i, j)] = possible_actions
            

    # Define an initial policy
    policy = {}

    for s in actions.keys():
        try:
            policy[s] = np.random.choice(actions[s])
        except: pass

    #print(f'policy: {policy}')
    # Policy iteration
    policy = policy_iteration(robot, policy, values, rewards, actions)
    # Randomly select where to go based on policy
    best_direction = policy[robot.pos]
    while robot.orientation != best_direction:
        robot.rotate('r')
    robot.move()
    #print('moved', best_direction)


def policy_iteration(robot, policy, values, rewards, actions):
    '''
    Policy iteration

    Input:
    robot - a Robot object used to interact with the environment
    '''
    # print('Policy iteration')
    for _ in range(max_iter):
        policy_prev = policy.copy()
        #print(rewards)

        values = policy_evaluation(robot, policy, values, rewards)

        policy = policy_improvement(robot, policy, values, rewards, actions)

        # Early stopping
        if policy_prev == policy:
            print('stopped early convergence (main)')
            break
    return policy


def policy_evaluation(robot, policy, values, rewards):
    '''
    Evaluation of policy

    Input:
    robot - a Robot object used to interact with the environment
    '''
    #print('    Policy evaluation')
    for _ in range(max_iter):
        V_prev = values.copy()
        #print(f'v_prev: {V_prev}')
        # Calculate weighted score of state after each possible action
        for s in policy.keys():
            a = policy[s]
            values[s] = rewards[s] + discount * V_prev[get_next_state(s, a)] 
        # Early stopping
        #print(f'values: {values}')
        if V_prev == values:
            print('stopped early convergence (eval)')
            break
    return values


def policy_improvement(robot, policy, values, rewards, actions):
    '''
    Improvement update pass in policy

    Input:
    robot - a Robot object used to interact with the environment
    '''
    # print('    Policy improvement')
    # Calculate Q value
    Q = {}
    # Calculate weighted score of each possible action
    for i in range(robot.grid.n_cols):
        for j in range(robot.grid.n_rows):
            s = (i,j)
            Q = {}
            try:
                for a in actions[s]:
                    Q[a] = rewards[s] + discount * values[get_next_state(s, a)]
                try:
                    policy[s] = max(Q, key=Q.get)
                except: pass
            except: pass

    #print(f'policy after improvement: {policy}')

    return policy


def get_next_state(s, a):
    if a == 'e':
        try: return (s[0]+1, s[1])
        except IndexError: return (s[0], s[1])
    if a == 's':
        try: return (s[0], s[1]+1)
        except IndexError: return (s[0], s[1])
    if a == 'w':
        try: return (s[0]-1, s[1])
        except IndexError: return (s[0], s[1])
    if a == 'n':
        try: return (s[0], s[1]-1)
        except IndexError: return (s[0], s[1]) 

def get_possible_actions(grid, s):
    possible_actions = []

    try:
        if grid.cells[s[0]+1, s[1]] >= 0:
            possible_actions.append("e")
    except IndexError: pass
    try:
        if grid.cells[s[0], s[1]+1] >= 0:
            possible_actions.append("s")
    except IndexError: pass
    try:
        if grid.cells[s[0]-1, s[1]] >= 0:
            possible_actions.append("w")
    except IndexError: pass
    try:
        if grid.cells[s[0], s[1]-1] >= 0:
            possible_actions.append("n")
    except IndexError: pass
    return possible_actions