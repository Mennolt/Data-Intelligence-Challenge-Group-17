# Rotate endlessly to have a second robot in our experiments
def robot_epoch(robot):
    robot.rotate('l')
    robot.move()